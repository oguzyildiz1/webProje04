from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

def anasayfa(request):
    return HttpResponse("Ana sayfaya hoş geldiniz.")
