# anasayfa app te urls.py diye bir dosya oluştur, bunları ekle
from django.urls import path
from . import views

urlpatterns = [
    path('hakkimda/', views.hakkimda, name='hakkimda'),
    path('', views.hakkimda, name='hakkimda'),
]
