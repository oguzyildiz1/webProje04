from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

def hakkimda(request):
    return HttpResponse("Hakkımda sayfasına hoş geldiniz..")